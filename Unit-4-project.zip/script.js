let usethistoswitchquestions1var = document.querySelector(".usethistoswitchquestions1");
let usethistoswitchquestions2var = document.querySelector(".usethistoswitchquestions2");
let usethistoswitchquestions3var = document.querySelector(".usethistoswitchquestions3");
let usethistoswitchquestions4var = document.querySelector(".usethistoswitchquestions4");
let usethistoswitchquestions5var = document.querySelector(".usethistoswitchquestions5");
let usethistoswitchquestions6var = document.querySelector(".usethistoswitchquestions6");
let usethistoswitchquestions7var = document.querySelector(".usethistoswitchquestions7");

let wrong = document.querySelector(".wrongAnswer");

let CorrectAnswer1var = document.querySelector(".CorrectAnswer1");
let CorrectAnswer2var = document.querySelector(".CorrectAnswer2");
let CorrectAnswer3var = document.querySelector(".CorrectAnswer3");
let CorrectAnswer4var = document.querySelector(".CorrectAnswer4");
let CorrectAnswer5var = document.querySelector(".CorrectAnswer5");
let replay = document.querySelector(".replaybutton");
 
/* wrong.addEventListener("click", function() {
    alert("You choose wrong!");
}); */



  CorrectAnswer1var.addEventListener("click", function() {
    usethistoswitchquestions1var.style.display = "none";
    usethistoswitchquestions2var.style.display = "block";
});
 CorrectAnswer2var.addEventListener("click", function() {
    usethistoswitchquestions2var.style.display = "none";
    usethistoswitchquestions3var.style.display = "block";
});
 CorrectAnswer3var.addEventListener("click", function() {
    usethistoswitchquestions3var.style.display = "none";
    usethistoswitchquestions4var.style.display = "block";
});
 CorrectAnswer4var.addEventListener("click", function() {
    usethistoswitchquestions4var.style.display = "none";
    usethistoswitchquestions5var.style.display = "block";
});
 CorrectAnswer5var.addEventListener("click", function() {
    usethistoswitchquestions5var.style.display = "none";
    usethistoswitchquestions6var.style.display = "block";
});

let submitbuttonvar = document.querySelector(".submitbutton");

  submitbuttonvar.addEventListener("click", function() {
  
  let days = parseInt(document.querySelector(".days").value);

if (days === 5) {
  usethistoswitchquestions6var.style.display = "none";
  usethistoswitchquestions7var.style.display = "block";
}
});

 replay.addEventListener("click", function() {
    usethistoswitchquestions7var.style.display = "none";
    usethistoswitchquestions1var.style.display = "block";
});